package com.shoppingapp.OnlineShoppingApp.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.shoppingapp.OnlineShoppingApp.controller.ProductController;
import com.shoppingapp.OnlineShoppingApp.exception.ProductAlreadyPresentException;
import com.shoppingapp.OnlineShoppingApp.model.Product;
import com.shoppingapp.OnlineShoppingApp.model.UserInfo;
import com.shoppingapp.OnlineShoppingApp.service.ProductService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(value= ProductController.class)
public class productController {
    @Autowired
    private ProductService productService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    private List<Product> productList1;

    @Test
    @DisplayName("Add_Product")
    public void testAddUser() throws Exception, ProductAlreadyPresentException {


            Product product=new Product();
            product.setId("6");
            product.setProductId(6);
            product.setProductName("KTM");
            product.setProductDesc("Bike");
            product.setPrice(120000);
            product.setFeatures("Good");
            product.setQuantity(70);
            product.setProductStatus("Available");



            when(productService.addProduct(any(Product.class))).thenReturn(product);
            this.mockMvc.perform(post("/add")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(product)))
                    .andExpect(status().isOk());

    }


    @Test
    @DisplayName("Get_All_Product")
    public void testGetAllProductList() throws Exception {
        //  Product product=new Product();
        this.productList1 = new ArrayList<>();
        this.productList1.add(new Product("7",7, "Dell", "Laptop", 32000,"Good",70,"Available"));

        when(productService.getAllProducts()).thenReturn(productList1);
        this.mockMvc.perform(get("/all")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());

    }


}
