package com.shoppingapp.OnlineShoppingApp.controller;

import com.shoppingapp.OnlineShoppingApp.controller.LoginController;
import com.shoppingapp.OnlineShoppingApp.model.UserInfo;
import com.shoppingapp.OnlineShoppingApp.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.junit.Test;

@RunWith(SpringRunner.class)
@WebMvcTest(value= LoginController.class)
public class loginControllerTest {

    @Autowired
    private LoginService loginService;

    @MockBean
    private UserDetailsService userDetailsService;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Add_User/Admin")

    public void testAddUser() throws  Exception{

        UserInfo user=new UserInfo();
        user.setLoginId("5");
        user.setFirstName("Subham");
        user.setFirstName("Kumar");
        user.setPassword("12345");
        user.setConfirmPassword("12345");
        user.setEmail("Subham@gmail.com");
        user.setRoles("ROLE_USER");


        when(loginService.addUser(any(UserInfo.class))).thenReturn(user);
        this.mockMvc.perform(post("/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk());

    }
}
